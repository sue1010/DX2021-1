#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>

#define MAX_STACK_SIZE 1000000
#define MAX_MAZE_SIZE 1001

typedef struct {
    int row;
    int col;
    int dir;
} element;

element stack[MAX_STACK_SIZE];
int top = -1;

bool isEmpty() {
    return top < 0;
}

bool isFull() {
    return top >= MAX_STACK_SIZE - 1;
}

void stackFull()
{
    fprintf(stderr, "Stack is Full, cannot push element");
    exit(EXIT_FAILURE);
}

element stackEmpty()
{
    fprintf(stderr, "Stack is Empty, cannot pop element");
    element tmp;
    return tmp;
}

void push(element item)
{
    if (isFull())
        stackFull();
    stack[++top] = item;
}

element pop()
{
    if (isEmpty())
        return stackEmpty();
    return stack[top--];
}

typedef struct {
    int vert;
    int horiz;
} offsets;

offsets move[8]={{-1, 0}, {-1,1}, {0,1}, {1,1}, {1,0}, {1,-1}, {0,-1}, {-1,-1}};


int maze[MAX_MAZE_SIZE+2][MAX_MAZE_SIZE+2];
int mark[MAX_MAZE_SIZE+2][MAX_MAZE_SIZE+2] = {0};
int EXIT_ROW, EXIT_COL;


void path()
{
    int i, row, col, nextRow, nextCol, dir, found=0;
    element position;

    mark[1][1] = 1; 
    position.row = 1;
    position.col = 1;
    position.dir = 0;
    push(position);

    while (!isEmpty() && !found) {
        position = pop();
        row = position.row; 
        col = position.col;
        dir = position.dir;

        while (dir < 8 && !found) {
            nextRow = row + move[dir].vert;
            nextCol = col + move[dir].horiz;

            if (nextRow == EXIT_ROW && nextCol == EXIT_COL)
                found = 1;
            else if (!maze[nextRow][nextCol] && !mark[nextRow][nextCol]) {
                mark[nextRow][nextCol] = 1;
                position.row = row;
                position.col = col;
                position.dir = ++dir;
                push(position);

                row = nextRow;
                col = nextCol;
                dir = 0;
            }
            else ++dir;
        }
    }
    if (found) {
        printf("%d %d\n", EXIT_ROW, EXIT_COL);
        printf("%d %d\n", row, col);
        while (!isEmpty()) {
            position = pop();
            printf("%d %d\n", position.row, position.col);
        }
    }
    else
        printf("No path in maze\n");
}


int main()
{
    int i, j, n, m, k;
    scanf("%d %d\n", &n, &m);
    for (i = 0; i <= n+1; i++) {
        for (j = 0; j <= m+1; j++) {
            maze[i][j] = 1;
        }
    }

    for (i = 1; i <= n; i++) {
        for (j = 1; j <= m; j++) {
            scanf("%d", &maze[i][j]);
        }
    }
    EXIT_ROW = n, EXIT_COL = m;

    path();
    return 0;
}
