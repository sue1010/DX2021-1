#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>

int MAX_QUEUE_SIZE;

typedef struct {
    int key;
    /* some fields */
} element;

element *queue;
int front = 0;
int rear = 0;

void queueFull(int key)
{
    printf("Queue is Full, cannot push element %d\n", key);
}

element queueEmpty()
{
    printf("Queue is Empty, cannot pop element\n");
    element tmp;
    return tmp;
}

void push(element item)
{
    rear = (rear + 1) % MAX_QUEUE_SIZE;
    if (front == rear) {
        queueFull(item.key);
        if (rear - 1 < 0)
            rear = MAX_QUEUE_SIZE - 1; 
        else
            rear--;
        return;
    }
    queue[rear] = item;
}

element pop()
{
    if (front == rear)
        return queueEmpty();
    front = (front + 1) % MAX_QUEUE_SIZE; 
    return queue[front];
}

void print()
{
    if (front == rear)
        return;

    int i;
    if (rear >= front) {
        for(i = front+1; i <= rear; i++)
            printf("%d ", queue[i].key);
    }
    else {
        for(i = front+1; i < MAX_QUEUE_SIZE; i++)
            printf("%d ", queue[i].key);

        for(i = 0; i <= rear; i++)
            printf("%d ", queue[i].key);
    }
    printf("\n");
}

int main()
{
    int i, n, k;
    element a;
    scanf("%d %d", &MAX_QUEUE_SIZE, &n); 
    queue = (element *) malloc(sizeof(element));
    for (i=0; i<n; i++) {
        scanf("%d", &k);
        if (k == -1)
            pop();
        else if (k == 0)
            print();
        else {
            a.key = k;
            push(a);
        }
    }
    free(queue);
    return 0;
}
