#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>

#define MAX_STACK_SIZE 100
#define MAX_EXPR_SIZE 100

typedef enum {lparen, rparen, plus, minus, 
    times, divide, mod, eos, operand
} precedence;

precedence stack[MAX_STACK_SIZE];
static int isp[] = {0,19,12,12,13,13,13,0};
static int icp[] = {20,19,12,12,13,13,13,0};
int top = -1;

char expr[MAX_EXPR_SIZE];
char post[MAX_EXPR_SIZE];
char *postp;

bool isEmpty() {
    return top < 0;
}

bool isFull() {
    return top >= MAX_STACK_SIZE - 1;
}

void stackFull()
{
    fprintf(stderr, "Stack is Full, cannot push element");
    exit(EXIT_FAILURE);
}

precedence stackEmpty()
{
    fprintf(stderr, "Stack is Empty, cannot pop element");
    precedence tmp;
    return tmp;
}

void push(precedence item)
{
    if (isFull())
        stackFull();
    stack[++top] = item;
}

precedence pop()
{
    if (isEmpty())
        return stackEmpty();
    return stack[top--];
}

precedence peek()
{
    if (isEmpty())
        return stackEmpty();
    return stack[top];
}

precedence getToken(char *symbol, char *expr, int *n)
{
    *symbol = expr[(*n)++];
    switch(*symbol){
        case 0: return eos;
        case ')': return rparen;
        case '+': return plus;
        case '-': return minus;
        case '*': return times;
        case '/': return divide;
        case '%': return mod;
        case '(': return lparen;
        default: return operand;
    }
}

void printToken(precedence p) 
{
    switch(p){
        case plus: 
            // printf("%c", '+');
            postp += sprintf(postp, "%c", '+');
            break;
        case minus: 
            // printf("%c", '-');
            postp += sprintf(postp, "%c", '-');
            break;
        case times: 
            // printf("%c", '*');
            postp += sprintf(postp, "%c", '*');
            break;
        case divide: 
            // printf("%c", '/');
            postp += sprintf(postp, "%c", '/');
            break;
        case mod: 
            // printf("%c", '%');
            postp += sprintf(postp, "%c", '%');
            break;
        case eos: 
            // postp += sprintf(postp, "%c", '\0');
            break;
    }
}

void postfix(char *expr)
{
    char symbol;
    precedence token;
    int n = 0;
    push(eos);
    for (token = getToken(&symbol, expr, &n); token != eos; token = getToken(&symbol, expr, &n)) {
        if (token == operand){
            // printf("%c", symbol);
            postp += sprintf(postp, "%c", symbol);
        }
        else if (token == rparen) {
            while (peek() != lparen) {
                printToken(pop());
            }
            pop();
        }
        else {
            while (isp[peek()] >= icp[token]) 
               printToken(pop());
            push(token);
        }
    }
    while ((token=pop()) != eos)
        printToken(token);
    // printf("\n");
}

int eval(char *expr)
{
   precedence token;
   char symbol;
   int op1, op2;
   int n = 0;
   token = getToken(&symbol, expr, &n);
   while (token != eos) {
      if (token == operand)
         push(symbol-'0');
      else {
         op2 = pop();
         op1 = pop();
         switch(token) {
            case plus: 
                push(op1+op2);
                break;
            case minus: 
                push(op1-op2);                   
                break;
            case times: 
                push(op1*op2);                    
                break;
            case divide: 
                push(op1/op2);                   
                break;
            case mod: 
                push(op1%op2);
         }
      }
      token = getToken(&symbol, expr, &n);
   }
   return pop();
}


int main()
{
    int i, n, val;
    postp = post;
    scanf("%d", &n);
    for (i = 0; i < n; i++) { 
        scanf("%s", expr);
        postfix(expr);
        printf("%s\n", post);
        val = eval(post);
        printf("%d\n", val);
        
        // initialize
        top = -1;
        post[0] = '\0';
        postp = post;
    }
    return 0;
}
