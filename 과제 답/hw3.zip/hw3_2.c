#include <stdio.h>
#include <stdlib.h>

#define COMPARE(x, y) ((x) < (y) ? -1 : ((x) == (y)) ? 0 : 1)
#define MALLOC(p, s) \
    if (!((p) = malloc(s))) { \
        fprintf(stderr, "Insufficient memory"); \
        exit(EXIT_FAILURE);\
    }

typedef struct polyNode *polyPointer;
typedef struct polyNode{
    int coef;
    int expon;
    polyPointer link;
}polyNode;

void attach(int, int, polyPointer *);

polyPointer padd(polyPointer a, polyPointer b)
{
    polyPointer c, rear, temp;
    int sum;
    MALLOC(rear, sizeof(*rear));
    c = rear;
    while(a && b) {
        switch(COMPARE(a->expon, b->expon)) {
            case -1: /* a->expon < b->expon */
                attach(b->coef, b->expon, &rear);
                b = b->link;
                break;
            case 0 : /* a->expon = b->expon */
                sum = a->coef + b->coef;
                if(sum) 
                    attach(sum, a->expon, &rear);
                a = a->link; 
                b = b->link; 
                break;
            case 1: /* a->expon > b->expon */
                attach(a->coef, a->expon, &rear);
                a = a->link;
        }
    }

    for(; a; a=a->link) {
        attach(a->coef, a->expon, &rear);
    }
    for(; b; b=b->link) {
        attach(b->coef, b->expon, &rear);
    }

    rear->link = NULL;
    temp = c; 
    c = c->link; 
    free(temp);
    return c;
}

void attach(int coefficient, int exponent, polyPointer *ptr)
{     
    polyPointer temp;
    MALLOC(temp, sizeof(*temp));
    temp->coef = coefficient;
    temp->expon = exponent;
    (*ptr)->link = temp;
    *ptr = temp;
}

int main()
{
    int i, n, m, j, k;
    scanf("%d %d", &n, &m);
    polyPointer a, b, inputa, inputb, temp, c = NULL;
    MALLOC(a, sizeof(*a));
    MALLOC(b, sizeof(*b));

    MALLOC(inputa, sizeof(*inputa));
    a = inputa;

    for(i = 0; i < n; i++) {
        scanf("%d %d", &j, &k);
        attach(j, k, &inputa);
    }
    inputa->link = NULL;
    temp = a; 
    a = a->link; 

    MALLOC(inputb, sizeof(*inputb));
    b = inputb;

    for(i = 0; i < m; i++) {
        scanf("%d %d", &j, &k);
        attach(j, k, &inputb);
    }
    inputb->link = NULL;
    temp = b; 
    b = b->link; 

    c = padd(a, b);

    // print
    for(; c; c=c->link) {
        printf("%d %d ", c->coef, c->expon);
    }
    printf("\n");

    return 0;
}
