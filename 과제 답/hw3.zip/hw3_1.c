#include <stdio.h>
#include <stdlib.h>

#define MALLOC(p, s) \
    if (!((p) = malloc(s))) { \
        fprintf(stderr, "Insufficient memory"); \
        exit(EXIT_FAILURE);\
    }

typedef struct listNode *listPointer;
typedef struct listNode {
    int data;
    listPointer link;
} listNode;


void insert(listPointer *firstp, int value)
{
    listPointer temp;
    MALLOC(temp, sizeof(*temp));
    temp->data = value;

    listPointer cur = *firstp, prev = NULL;
    if(cur) {
        while (cur != NULL) {
            prev = cur;
            cur = cur->link;
        }

        temp->link = NULL;
        prev->link = temp;
    }
    else {
        temp->link = NULL;
        *firstp = temp;
    }
}

void find_delete(listPointer *firstp, int value)
{
    listPointer prev = NULL;
    listPointer cur = *firstp;
    for( ; cur; cur = cur->link) {
        if (cur->data == value) {
            if (prev) {
                prev->link = cur->link;
            }
            else {
                *firstp = (*firstp)->link; 
            }
        }
        else {
            prev = cur;
        }
    }
}

void print(listPointer first)
{
    listPointer cur = first;
    while (cur != NULL) {
        printf("%d ", cur->data);
        cur = cur->link;
    }
    printf("\n");
}

int main()
{
    listPointer first = NULL;
    int num;
    scanf("%d", &num);
    while (num != -1) {
        insert(&first, num);
        scanf("%d", &num);
    }
    scanf("%d", &num);
    while (num != -1) {
        find_delete(&first, num);
        scanf("%d", &num);
    }

    print(first);
    return 0;
}

