#include <stdio.h>

#define MAX_TERMS 10000001

typedef  struct {
    int col;
    int row;
    int value;
} term;

term a[MAX_TERMS];

int main()
{
    int i, j, n, m, k, v;
    int t = 1;
    scanf("%d %d %d", &n, &m, &k);
    a[0].row = n;
    a[0].col = m;

    for(i = 0; i < n; i++) {
        for(j = 0; j < m; j++) {
            scanf("%d", &v);
            if (v == 0)
                continue;

            a[t].row = i;
            a[t].col = j;
            a[t++].value = v;
        }
    }

    a[0].value = t - 1;
    for(i = 0; i < k; i++) {
        scanf("%d", &v); 
        printf("%d %d %d\n", a[v].row, a[v].col, a[v].value);
    }

    return 0;
}
