#include <stdio.h>
#include <stdlib.h>

#define COMPARE(x, y) ((x) < (y) ? -1 : ((x) == (y)) ? 0 : 1)
#define MAX_TERMS 2002

typedef struct {
    float coef;
    int expon;
} polynomial;

polynomial terms[MAX_TERMS];
int avail = 0;

void attach(float coefficient, int exponent)
{            
    if (avail >= MAX_TERMS) {
        fprintf(stderr, "Too many terms in polynomials");
        exit(1);
    }
    terms[avail].coef = coefficient;
    terms[avail++].expon = exponent;
}

/* C = A + B */
void padd(int starta, int finisha, int startb, int finishb, int *startd, int *finishd)
{
    float coefficient;
    *startd = avail;
    while (starta <= finisha && startb <= finishb) {
        switch (COMPARE(terms[starta].expon, terms[startb].expon)) {
            case -1:
                attach(terms[startb].coef, terms[startb].expon);
                startb++; 
                break;
            case 0:
                coefficient = terms[starta].coef + terms[startb].coef;
                if(coefficient) 
                    attach(coefficient, terms[starta].expon);
                starta++; startb++; 
                break;
            case 1:
                attach(terms[starta].coef, terms[starta].expon);
                starta++;   
        }
    }
    for(; starta <= finisha; starta++)
        attach(terms[starta].coef, terms[starta].expon);

    for(; startb <= finishb; startb++)
        attach(terms[startb].coef, terms[startb].expon);
    *finishd = avail - 1; 
}

int main()
{
    int i, n, m, j, k;
    scanf("%d %d", &n, &m);
    for(i = 0; i < n; i++) {
        scanf("%d %d", &j, &k);
        attach(j, k);
    }
    for(i = 0; i < m; i++) {
        scanf("%d %d", &j, &k);
        attach(j, k);
    }

    int *startd = malloc(sizeof(int));
    int *finishd = malloc(sizeof(int));
    padd(0, n-1, n, n+m-1, startd, finishd);
    printf("%d %d\n", *startd, *finishd);
    for(i = *startd; i <= *finishd; i++) {
        printf("%.0f %d ", terms[i].coef, terms[i].expon);
    }
    printf("\n");

    return 0;
}
