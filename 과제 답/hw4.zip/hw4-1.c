#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#define MAX_QUEUE_SIZE 100

typedef struct node *treePointer;
typedef struct node{
   int data;
   treePointer leftChild, rightChild;
} node;
treePointer new_node(treePointer ptr,int val)
{
   ptr->data = val;
   ptr->leftChild = NULL, ptr->rightChild =NULL;
   return ptr;
}

treePointer queue[MAX_QUEUE_SIZE];
int front = -1;
int rear = -1;
void q_clear()
{
   memset(queue,0,sizeof(queue));
   front = -1;
   rear = -1;
}
bool isEmpty()
{
   return front == rear;
}
void push(treePointer item)
{
   queue[++rear] = item;
}
treePointer pop()
{
   return queue[++front];
}
void inorder(treePointer ptr)
{
   if (ptr)
   {
      inorder(ptr->leftChild);
      if(ptr->data != 0) printf("%d ",ptr->data);
      inorder(ptr->rightChild);
   }
}
void preorder(treePointer ptr)
{
   if(ptr){
      if(ptr->data != 0) printf("%d ",ptr->data);
      preorder(ptr->leftChild);
      preorder(ptr->rightChild);
   }
}
void postorder(treePointer ptr)
{
   if(ptr)
   {
      postorder(ptr->leftChild);
      postorder(ptr->rightChild);
      if(ptr->data != 0) printf("%d ",ptr->data);
   }
}
void levelorder(treePointer ptr)
{
   q_clear();
   if(!ptr) return;
   push(ptr);
   while(!isEmpty())
   {
      ptr = pop();
      if (ptr)
      {
         if (ptr->data != 0){
         printf("%d ",ptr->data);
         }
         if(ptr->leftChild)
            push(ptr->leftChild);
         if (ptr->rightChild)
            push(ptr->rightChild);
      }
   }
}

void insert(treePointer root, int val)
{
   push(root);
   while(!isEmpty())
   {
      treePointer front = pop();
      treePointer temp;
      temp = (treePointer)malloc(sizeof(*temp));
      if(!front->leftChild){
         front->leftChild = new_node(temp, val);
         return;
      }else{
         push(front->leftChild);
      }
      if(!front->rightChild){
         front->rightChild = new_node(temp, val);
         return;
      }else{
         push(front->rightChild);
      }
   }
}
int main()
{
   int n;
   scanf("%d",&n);
   while(n--)
   {
      int arr[100];
      int i =0;
      for(i=0;;i++)
      {
         int tmp;
         scanf("%d",&tmp);
         if(tmp == -1) break;
         arr[i] = tmp;
      }
      int size = i;
      treePointer root;
      root = (treePointer)malloc(sizeof(*root));
      root = new_node(root,arr[0]);
      for(int i = 1 ;i<size;i++)
      {
         insert(root, arr[i]);
         q_clear();
      }

      inorder(root);
      printf("\n");
      preorder(root);
      printf("\n");
      postorder(root);
      printf("\n");
      levelorder(root);
      printf("\n");
      q_clear();
      memset(arr,0,sizeof(arr));
   }
   return 0;
}
