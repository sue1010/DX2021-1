#include <stdio.h>
#include <stdlib.h>

#define MALLOC(p, s) \
    if (!((p) = malloc(s))) { \
        fprintf(stderr, "Insufficient memory"); \
        exit(EXIT_FAILURE);\
    }


typedef struct treeNode *treePointer;
typedef struct treeNode{
    int data;
    treePointer leftChild, rightChild;
}treeNode;


treePointer createNode(int key)
{
    treePointer tmp;
    MALLOC(tmp, sizeof(*tmp));
    tmp->data = key;
    tmp->leftChild = tmp->rightChild = NULL;
    return tmp;
}

treePointer insert(treePointer ptr, int key)
{
    if (!ptr) {
        return createNode(key);
    }
    if (key < ptr->data) {
        ptr->leftChild = insert(ptr->leftChild, key);
    }
    else {
        ptr->rightChild = insert(ptr->rightChild, key);
    }
    return ptr;
}

treePointer maxNode(treePointer ptr)
{
    treePointer current = ptr;
    while (current && current->rightChild != NULL) {
        current = current->rightChild;
    }

    return current;
}

treePointer search_insert_delete(treePointer ptr, int key)
{
    if (!ptr) {
        return createNode(key);
    } 

    if (key < ptr->data) {
        ptr->leftChild = search_insert_delete(ptr->leftChild, key);
    }
    else if (key > ptr->data) {
        ptr->rightChild = search_insert_delete(ptr->rightChild, key);
    }
    else {
        if (!ptr->leftChild) {
            treePointer temp = ptr->rightChild;
            free(ptr);
            return temp;
        }
        else if (!ptr->rightChild) {
            treePointer temp = ptr->leftChild;
            free(ptr);
            return temp;
        }
        treePointer temp = maxNode(ptr->leftChild);
        ptr->data = temp->data;
        ptr->leftChild = search_insert_delete(ptr->leftChild, temp->data);
    }
    return ptr;
}

treePointer delete(treePointer ptr, int key)
{
    if (!ptr) {
        return ptr;
    }

    if (key < ptr->data) {
        ptr->leftChild = delete(ptr->leftChild, key);
    }
    else if (key > ptr->data) {
        ptr->rightChild = delete(ptr->rightChild, key);
    }
    else {
        if (!ptr->leftChild) {
            treePointer temp = ptr->rightChild;
            free(ptr);
            return temp;
        }
        else if (!ptr->rightChild) {
            treePointer temp = ptr->leftChild;
            free(ptr);
            return temp;
        }
        treePointer temp = maxNode(ptr->leftChild);
        ptr->data = temp->data;
        ptr->leftChild = delete(ptr->leftChild, temp->data);
    }
    return ptr;
}

void preorder(treePointer ptr) 
{
    if (ptr) {
        printf("%d ", ptr->data);
        preorder(ptr->leftChild);
        preorder(ptr->rightChild);
    }
}

int main()
{
    int num;
    treePointer root = NULL;

    scanf("%d", &num);
    while (num != -1) {
        root = insert(root, num);
        scanf("%d", &num);
    }

    scanf("%d", &num);
    while (num != -1) {
        root = search_insert_delete(root, num);
        preorder(root);
        printf("\n");
        scanf("%d", &num);
    }
    
    return 0;
}
