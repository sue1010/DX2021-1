#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int heap[100];
int n = 0;

void push(int item)
{
    int i;
    // check whether the heap is full or not
    if (n > 100) {
        fprintf(stderr, "The heap is full");
        exit(EXIT_FAILURE);
    }
    
    i = ++n;
    while ((i != 1) && item > heap[i/2]) {
        heap[i] = heap[i/2];
        i /= 2;
    }
    heap[i] = item;
}

void swap(int *a, int *b)
{
    int temp = *a;
    *a = *b;
    *b = temp;
}

void heapify(int i)
{
    int largest = i;
    int l = 2 * i;
    int r = 2 * i + 1;

    if (l < n && heap[l] > heap[largest])
        largest = l;

    if (r < n && heap[r] > heap[largest])
        largest = l;

    if (largest != i) {
        swap(&heap[i], &heap[largest]);
        heapify(largest);
    }
}

int pop()
{
    int item = heap[1];
    swap(&heap[1], &heap[n]);
    // same as "int temp = heap[n]; heap[1] = temp;"
    n = n - 1;
    heapify(1); // heapify the root node
    return item;
}

void print()
{
    int i;
    for (i = 1; i <= n; i++) {
        printf("%d ", heap[i]);
    }
    printf("\n");
}

int main()
{
    int i, n, num;
    scanf("%d", &n);
    for (i = 0; i < n; i++)
    {
        scanf("%d", &num);
        if (num == 0) {
            print();
        }
        else if (num == -1) {
            pop();
        }
        else {
            push(num); 
        }
    }
    return 0;
}
