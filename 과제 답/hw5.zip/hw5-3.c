#include <stdio.h>
#include <stdlib.h>

#define COMPARE(x, y) ((x) < (y) ? -1 : ((x) == (y)) ? 0 : 1)
#define MALLOC(p, s) \
    if (!((p) = malloc(s))) { \
        fprintf(stderr, "Insufficient memory"); \
        exit(EXIT_FAILURE);\
    }
#define MAX_VERTICES 100

typedef struct node *nodePointer;
typedef struct node {
    int vertex;
    nodePointer link;
} node;

typedef struct hdnodes {
    int count;
    nodePointer link;
} hdnodes;
hdnodes graph[MAX_VERTICES];

int n;

void topSort()
{
    int i, j, k, top;
    nodePointer ptr;
    top = -1;
    for (i=0; i<n; i++) {
        if (!graph[i].count) {
            graph[i].count = top;
            top = i;
        }
    }

    for (i=0; i<n; i++) {
        if (top == -1) {
            fprintf(stderr, "\nNetwork has a cycle. Sort terminated. \n");
            exit(EXIT_FAILURE);
        }
        else {
            j = top;  /* unstack a vertex */
            top = graph[top].count;
            printf("%d ", j);
            for (ptr = graph[j].link; ptr; ptr = ptr->link) {
                k = ptr->vertex;
                graph[k].count--;
                if (!graph[k].count) {
                    graph[k].count = top; 
                    top = k;
                }
            }
        }
    }
}

void attach(int src, int dest)
{     
    nodePointer newNode, temp;
    MALLOC(newNode, sizeof(*newNode));
    newNode->vertex = dest;

    graph[dest].count++;
    temp = graph[src].link;
    if (temp == NULL) {
        graph[src].link = newNode;
    }
    else {
        while (temp->link != NULL) { 
            temp = temp->link; 
        } 
        temp->link = newNode;
    }
}

int main()
{
    int i, x, y, cases;
    scanf("%d %d", &n, &cases);
    for (i = 0; i < n; i++) {
        graph[i].count = 0;
        graph[i].link = NULL;
    }

    for (i = 0; i < cases; i++) {
        scanf("%d %d", &x, &y);
        attach(x, y);    
    }
    topSort();
    return 0;
}
