#include <stdio.h>
#include <stdlib.h>

#define COMPARE(x, y) ((x) < (y) ? -1 : ((x) == (y)) ? 0 : 1)
#define MALLOC(p, s) \
    if (!((p) = malloc(s))) { \
        fprintf(stderr, "Insufficient memory"); \
        exit(EXIT_FAILURE);\
    }

#define MAX_NODE 100
#define MAX_QUEUE_SIZE 100

int graph[MAX_NODE][MAX_NODE];
int visited[MAX_NODE];
int queue[MAX_QUEUE_SIZE];
int front = 0;
int rear = 0;
int n;

void queueFull()
{
    printf("Queue is Full, cannot push element\n");
}

int queueEmpty()
{
    printf("Queue is Empty, cannot pop element\n");
    return -1;
}

void push(int node)
{
    rear = (rear + 1) % MAX_QUEUE_SIZE;
    if (front == rear) {
        queueFull();
        if (rear - 1 < 0)
            rear = MAX_QUEUE_SIZE - 1; 
        else
            rear--;
        return;
    }
    queue[rear] = node;
}

int pop()
{
    if (front == rear)
        return queueEmpty();
    front = (front + 1) % MAX_QUEUE_SIZE; 
    return queue[front];
}

int isEmpty()
{
    return front == rear;
}

void dfs(int v)
{
    int i;
    visited[v] = 1;
    printf("%d ", v);
    for (i=0; i<n; i++) {
        if (graph[v][i] && !visited[i]) {
            dfs(i);
        }
    }
}

void bfs(int v)
{
    int i;
    printf("%d ", v);
	push(v);
    visited[v] = 1;

	while (!isEmpty()) {
        v = pop(); 
        for (i=0; i<n; i++) {
            if (graph[v][i] && !visited[i]) {
                printf("%d ", i);
                push(i);
                visited[i] = 1;
            }
        }
	}
}

int main()
{
    int i, j, num;
    scanf("%d", &n);
    for (i = 0; i < n; i++) {
        for (j = 0; j < n; j++) {
            graph[i][j] = 0;
        }
    } 

    for (i = 0; i < n; i++) {
        for (j = 0; j < n; j++) {
            scanf("%d", &num);
            graph[i][j] = num;
        }
    }

    for (i = 0; i < n; i++) {
        visited[i] = 0;
    } 
    dfs(0);
    printf("\n");
    
    // initialize queue and visited 
    front = rear = 0;
    for (i = 0; i < n; i++) {
        visited[i] = 0;
    } 
    bfs(0);
    return 0;
}
