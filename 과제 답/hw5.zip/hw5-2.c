#include <stdio.h>
#include <stdlib.h>

#define COMPARE(x, y) ((x) < (y) ? -1 : ((x) == (y)) ? 0 : 1)
#define MALLOC(p, s) \
    if (!((p) = malloc(s))) { \
        fprintf(stderr, "Insufficient memory"); \
        exit(EXIT_FAILURE);\
    }

#define MAX_NODE 100
#define MAX_QUEUE_SIZE 100

typedef struct listNode *nodePointer;
typedef struct listNode {
    int vertex;
    nodePointer link;
} listNode;

nodePointer adjLists[MAX_NODE];
int visited[MAX_NODE];
int queue[MAX_QUEUE_SIZE];
int front = 0;
int rear = 0;

void queueFull()
{
    printf("Queue is Full, cannot push element\n");
}

int queueEmpty()
{
    printf("Queue is Empty, cannot pop element\n");
    return -1;
}

void push(int node)
{
    rear = (rear + 1) % MAX_QUEUE_SIZE;
    if (front == rear) {
        queueFull();
        if (rear - 1 < 0)
            rear = MAX_QUEUE_SIZE - 1; 
        else
            rear--;
        return;
    }
    queue[rear] = node;
}

int pop()
{
    if (front == rear)
        return queueEmpty();
    front = (front + 1) % MAX_QUEUE_SIZE; 
    return queue[front];
}

int isEmpty()
{
    return front == rear;
}


void dfs(int v)
{
    nodePointer w;
    visited[v] = 1;
    printf("%d ", v);
    for (w = adjLists[v]; w; w = w->link) {
        if (!visited[w->vertex])
            dfs(w->vertex);
    }
}

void bfs(int v)
{
    nodePointer w;
    front = rear = 0;
    printf("%d ", v);
    visited[v] = 1;
	push(v);
	while (!isEmpty()) {
        v = pop(); 
        for (w = adjLists[v]; w; w = w->link) {
            if (!visited[w->vertex]) {
        	    printf("%d ", w->vertex);
    		    push(w->vertex);
                visited[w->vertex] = 1;
            }
        }
	}
}

void insert(int v, nodePointer *ptr)
{
    nodePointer temp;
    MALLOC(temp, sizeof(*temp));
    temp->vertex = v;

    nodePointer cur = *ptr, prev = NULL;
    if(cur) {
        while (cur != NULL) {
            prev = cur;
            cur = cur->link;
        }
        temp->link = NULL;
        prev->link = temp;
    }
}

int main()
{
    int i, n, num;
    scanf("%d", &n);
    for (i = 0; i < n; i++) {
        MALLOC(adjLists[i], sizeof(*adjLists[i]));
    }

    for (i = 0; i < n; i++) {
        scanf("%d", &num);        
        while(num != -1) {
            insert(num, &adjLists[i]);
            scanf("%d", &num);
        }
    }

    for (i = 0; i < n; i++) {
        visited[i] = 0;
    } 
    dfs(0);
    printf("\n");
    
    // initialize queue and visited 
    front = rear = 0;
    for (i = 0; i < n; i++) {
        visited[i] = 0;
    } 

    bfs(0);
    return 0;
}
